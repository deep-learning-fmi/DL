from keras.models import Sequential
from keras.layers import Dense, LSTM, Dropout
from keras.layers.embeddings import Embedding

from metrics_utils import *

def create_lstm_model(emb_matrix, emb_size, vocab_size, no_cls, seq_size=150):
    # TODO 8.1. Build a sequential model
    model = # TODO

    # TODO 8.2. Add an embedding layer with the known vocab_size, emb_size, seq_size as input_length, [emb_matrix] as weights and trainable False for starters.
    
    # TODO 8.3. Add LSTM layer with 256 neurons, tanh as activation and that returns sequences
    
    # TODO 8.4. Add LSTM layer with 512 neurons, tanh as activation and that does not return sequences
    
    # TODO 8.5. Dropout 30% of the neurons
    
    # TODO 8.6. Add a Dense layer with 512 neurons and activation relu
    
    # TODO 8.7. Add another Dense layer with no_cls as number of neurons and softmax activation

    # TODO 8.8. Compile the model: binary crossentorpy as loss, Adam as optimizer, accuracy as metric.

    return model

def test_model(model, test_inputs, test_labels, batch_size):
    """
    Testing function
    """
    # Evaluate inputs
    results = model.evaluate(test_inputs, test_labels, batch_size=batch_size, verbose=1)
    
    # Predict
    predicts = model.predict(test_inputs, batch_size=batch_size, verbose=1)
    pred_arr = np.argmax(predicts, axis=1) 

    # F1 score weighted
    compute_print_f1(pred_arr, test_labels[:, 1], "weighted")
    # F1 score macro
    compute_print_f1(pred_arr, test_labels[:, 1], "macro")

    return results

