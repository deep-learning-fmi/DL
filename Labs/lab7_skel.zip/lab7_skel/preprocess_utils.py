import re
import string
import numpy as np
from nltk.corpus import stopwords
from nltk import SnowballStemmer
from keras.preprocessing.text import Tokenizer, text_to_word_sequence
from keras.preprocessing.sequence import pad_sequences

def preprocess_input(text_list):
    new_list = []
    for text in text_list:
        ## Remove puncuation
        text = text.translate(string.punctuation)
        
        ## Convert words to lower case and split them
        text = text.lower().split()
        
        ## Remove stop words
        stops = set(stopwords.words("romanian"))
        text = [w for w in text if not w in stops and len(w) >= 3]
        
        text = " ".join(text)
 
        ## Clean the text
        text = re.sub(r"[^A-Za-z0-9^,!.\/'+-=]", " ", text)
        text = re.sub(r",", " ", text)
        text = re.sub(r"\.", " ", text)
        text = re.sub(r"!", " ! ", text)
        text = re.sub(r"\/", " ", text)
        text = re.sub(r"\^", " ^ ", text)
        text = re.sub(r"\+", " + ", text)
        text = re.sub(r"\-", " - ", text)
        text = re.sub(r"\=", " = ", text)
        text = re.sub(r"'", " ", text)
        text = re.sub(r"(\d+)(k)", r"\g<1>000", text)
        text = re.sub(r":", " : ", text)
        text = re.sub(r"\s{2,}", " ", text)

        ## Stemming
        text = text.split()
        stemmer = SnowballStemmer('romanian')
        stemmed_words = [stemmer.stem(word) for word in text]
        text = " ".join(stemmed_words)

        new_list.append(text)

    return new_list

def tokenize(vocab_size, text):
    tokenizer = Tokenizer(num_words=vocab_size)
    tokenizer.fit_on_texts(text)
    return tokenizer

def samples_to_seq(tokenizer, samples):
    return  create_seq(tokenizer, samples)

def create_seq(tokenizer, text, maxlen=150):
    sequences = tokenizer.texts_to_sequences(text)
    data = pad_sequences(sequences, maxlen=maxlen)
    return data

