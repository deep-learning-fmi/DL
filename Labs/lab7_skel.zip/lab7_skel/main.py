import tensorflow as tf
import keras
from loadDataSet import *

config = tf.ConfigProto( device_count = {'GPU': 1 , 'CPU': 4} ) 
sess = tf.Session(config=config) 
keras.backend.set_session(sess)

import numpy as np
from metrics_utils import *
from preprocess_utils import *
from models import *
from embeddings_utils import *
from keras.callbacks import ModelCheckpoint

VOCAB_SIZE = 272785
EMB_SIZE = 300
EMB_PATH = "./glove_300/model.txt"
NO_CLASSES = 2

if __name__ == '__main__':
    # For TODO 1. visit loadDataSet.py
    # TODO 2. Load the data
    data_dict = # TODO

    # Concatenate train, validation and test
    all_data = data_dict[ALL][X]

    # TODO 3. Create tokenizer
    tokenizer = # TODO

    # TODO 4. Create sequences
    X_train = # TODO
    X_test = # TODO
    X_val = # TODO

    # TODO 5. Convert labels & one-hot encode them
    y_train = # TODO
    y_test = # TODO
    y_val = # TODO

    # Use pre-trained embeddings

    # TODO 6. Extract embeddings
    emb_index = # TODO
    # TODO 7. Create weight matrix
    emb_matrix = # TODO

    # For TODO 8. visit models.py and complete the tasks
    # TODO 9. Create the model
    model = # TODO

    # Fit train data
    filepath="checkpoints/weights-improvement-{epoch:02d}-acc-{val_accuracy:.2f}-loss-{val_loss:.2f}.hdf5"
    checkpoint = ModelCheckpoint(filepath, monitor='val_accuracy', verbose=1, save_best_only=True, mode='max')

    metrics = Metrics()
    callbacks_list = [checkpoint, metrics]

    model.fit(X_train, 
              np.array(y_train), 
              validation_data=(X_val, y_val), 
              batch_size = 128, 
              epochs = 1,
              callbacks = callbacks_list,
              verbose = 1)

    results = test_model(model, X_test, y_test, batch_size=128)
    model.save("model.h5")
    print(results) 
