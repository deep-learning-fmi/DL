import numpy as np

def extract_embeddings(emb_path):
    emb_index = dict()
    f = open(emb_path, encoding='utf-8', errors='ignore')
    for line in f:
        values = line.split()
        word = values[0]
        coefs = np.asarray(values[1:], dtype='float32')
        emb_index[word] = coefs
    f.close()
    return emb_index

def create_weight_matrix(tokenizer, emb_index, emb_size, vocab_size):
    emb_mat = np.zeros((vocab_size, emb_size))
    for word, index in tokenizer.word_index.items():
        if index > vocab_size - 1:
            break
        else:
            emb_vector = emb_index.get(word)
            if emb_vector is not None:
                emb_mat[index] = emb_vector

    return emb_mat
