import cv2
import glob
import matplotlib.pyplot as plt
import numpy as np
import os
import sys
import torch


device = torch.device('cuda')


# x = np.array([1, 2, 3])
# y = np.array([4, 5, 6])
# print(x)

# x = torch.Tensor(x)
# y = torch.Tensor(y)
# print(y[1])
# print(x.mean())
# print(torch.sum(x))
# print(x + y)
# print(x.shape)
# print(x * y)


class Model(torch.nn.Module):
    def __init__(self):
        super().__init__()

        self.conv = torch.nn.Sequential(
            torch.nn.Conv2d(3, 64, kernel_size = 5, padding = 2),
            torch.nn.ReLU(),
            torch.nn.MaxPool2d(2),

            torch.nn.Conv2d(64, 64, kernel_size = 5, padding = 2),
            torch.nn.ReLU(),
            torch.nn.MaxPool2d(2),
        )
        self.cls = torch.nn.Sequential(
            torch.nn.Linear(64 * 7 * 7, 128),
            torch.nn.ReLU(),
            torch.nn.Linear(128, 10)
        )



    def forward(self, input):
        output = self.conv(input)
        output = output.reshape(-1, 64 * 7 * 7)
        output = self.cls(output)

        return output


class Dataset(torch.utils.data.Dataset):
    def __init__(self, path):
        super().__init__()

        self.image_paths = glob.glob(path)
        self.n_samples = len(self.image_paths)

    def __getitem__(self, sample_n): # retrieve sameple number sample_n from the dataset
        image_path = self.image_paths[sample_n]
        im = cv2.imread(image_path)
        label = int(os.path.basename(image_path).split('_')[0])

        return im, label

    def __len__(self): # return the length of the dataset
        return self.n_samples

model = Model().to(device)
# model.load_state_dict(torch.load('./model'))
loss_f = torch.nn.CrossEntropyLoss()
optimizer = torch.optim.Adam(model.parameters(), lr = 1e-3)
# optimizer.load_state_dict(torch.load('./optimizer'))

ds = Dataset('./mnist/train/*')
dl = torch.utils.data.DataLoader(
    ds,
    batch_size = 128,
    shuffle = True,
    num_workers = 6
)
val_ds = Dataset('./mnist/val/*')
val_dl = torch.utils.data.DataLoader(
    val_ds,
    batch_size = 128,
    shuffle = True,
    num_workers = 6
)

best_val_acc = 0
for epoch_n in range(1):
    model.train()
    for batch in dl:
        model.zero_grad()

        input, target = batch 
        input = input.float().to(device).permute(0, 3, 1, 2)
        target = target.to(device)

        output = model(input)
        loss = loss_f(output, target)

        loss.backward()
        optimizer.step()

    # validate model
    model.eval()
    accs = []
    for batch in val_dl:
        input, target = batch 
        input = input.float().to(device).permute(0, 3, 1, 2)
        target = target.to(device)

        with torch.no_grad():
            output = model(input)

        predictions = output.argmax(1)
        acc = (predictions == target).float().mean().detach().cpu().numpy()
        accs.append(acc)
    val_acc = np.mean(accs)
    print(val_acc)
    # do not compute it like this because the last batch might not have 128 samples

    if val_acc > best_val_acc:
        # use loss to compare not accuracy
        torch.save(model.state_dict(), './model')
        torch.save(optimizer.state_dict(), './optimizer')
        best_val_acc = val_acc




# output = model(x)

# print(output.shape)

# output = output.detach().cpu().numpy()
# print(output)
