from os import listdir, makedirs
from os.path import isfile, join, splitext, exists
from copy import deepcopy
from keras.utils import to_categorical
from sklearn.model_selection import train_test_split
import random

# Assume the data set is in the below subfolder
TRAIN_PREFIX = "./aclImdb/train/"
TEST_PREFIX = "./aclImdb/test/"
POS_PREFIX = "pos"
NEG_PREFIX = "neg"
POS_LABEL = 1
NEG_LABEL = 0

ALL = "all"; TRAIN = "train"; TEST = "test"; VAL = "val"
NAME = "name"; X = "x"; Y = "y"

def labels_to_categ(y_lbls, cls_no=2):
    y_categ = deepcopy(y_lbls)
    y_categ = to_categorical(y_categ, num_classes = cls_no)
    return y_categ

def randomize_data(a, b, c):
    d = list(zip(a, b, c))
    random.shuffle(d)
    a, b, c = zip(*d)
    return a, b, c

def split_dataset(names, samples, labels, train_no = 0.8, val_no = 0.1, test_no = 0.1):
    d = {TRAIN: {NAME: None, X: None, Y: None},\
         TEST: {NAME: None, X: None, Y: None},\
         VAL: {NAME: None, X: None, Y: None}, \
         ALL: {NAME: names, X: samples, Y: labels}}

    names_samples = list(zip(names, samples))

    # Split initial dataset into train and test sets
    X_names_train, X_names_test, d[TRAIN][Y], d[TEST][Y] = \
        train_test_split(names_samples, labels, test_size=test_no, random_state=1)

    # Split remaining train and validation
    X_names_train, X_names_val, d[TRAIN][Y], d[VAL][Y] = \
        train_test_split(X_names_train, d[TRAIN][Y], test_size=val_no, random_state=1)

    # Unzip hashes and samples
    d[TRAIN][NAME], d[TRAIN][X] = zip(*X_names_train)
    d[VAL][NAME], d[VAL][X] = zip(*X_names_val)
    d[TEST][NAME], d[TEST][X] = zip(*X_names_test)

    return d

def load_from_file(path, label):
    """
    Load the names, contents and labels of the given type (neg, pos) 
    and purpose (train, test) of data.
    """
    names = []; contents = []; labels = []

    for name in listdir(path):
        names.append(name)
        with open(join(path, name), encoding='utf-8', errors='ignore') as f:
            contents.append(f.read())
        labels.append(label)

    return names, contents, labels

def load_from_dir(dname):
    # Load the positives
    pos_names, pos_contents, pos_labels = load_from_file(join(TRAIN_PREFIX, POS_PREFIX), POS_LABEL)
    # Load the negatives
    neg_names, neg_contents, neg_labels = load_from_file(join(TRAIN_PREFIX, NEG_PREFIX), NEG_LABEL)

    # Merge the sets
    names = pos_names + neg_names
    contents = pos_contents + neg_contents
    labels = pos_labels + neg_labels    

    return names, contents, labels
    

def load_dataset():
    # Load the training data
    train_fnames, train_content, train_lbls = load_from_dir(TRAIN_PREFIX)

    # Load the test data
    test_fnames, test_content, test_lbls = load_from_dir(TEST_PREFIX)

    # Add together all the properties
    names = train_fnames + test_fnames
    lbls = train_lbls + test_lbls
    content = train_content + test_content

    # Shuffle the data
    names, content, y = randomize_data(names, content, lbls)

    # Split again in train-validation-test (80-10-10)
    data_dict = split_dataset(names, content, y)

    print("Loaded %d training samples" % len(data_dict[TRAIN][X]))
    print("Loaded %d validation samples" % len(data_dict[VAL][X]))
    print("Loaded %d test samples" % len(data_dict[TEST][X]))

    return data_dict

if __name__ == "__main__":
    load_dataset()
