from keras.models import Sequential
from keras.layers import Dense, LSTM, Dropout
from keras.layers.embeddings import Embedding

from metrics_utils import *

def create_lstm_model(emb_matrix, emb_size, vocab_size, no_cls, seq_size=150):
    model = Sequential()

    model.add(Embedding(vocab_size, emb_size, input_length=seq_size, weights=[emb_matrix], trainable=False))
    model.add(LSTM(256, activation='tanh', return_sequences=True))
    model.add(LSTM(512, activation='tanh', return_sequences=False))
    model.add(Dropout(0.3))
    model.add(Dense(512, activation='relu'))
    model.add(Dense(no_cls, activation='softmax'))

    model.compile(loss='binary_crossentropy', optimizer='adam', metrics=['accuracy'])

    return model

def test_model(model, test_inputs, test_labels, batch_size):
    """
    Testing function
    """
    # Evaluate inputs
    results = model.evaluate(test_inputs, test_labels, batch_size=batch_size, verbose=1)
    
    # Predict
    predicts = model.predict(test_inputs, batch_size=batch_size, verbose=1)
    pred_arr = np.argmax(predicts, axis=1) 

    # F1 score weighted
    compute_print_f1(pred_arr, test_labels[:, 1], "weighted")
    # F1 score macro
    compute_print_f1(pred_arr, test_labels[:, 1], "macro")

    return results

