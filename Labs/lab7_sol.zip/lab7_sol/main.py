import tensorflow as tf
import keras
from loadDataSet import *

config = tf.ConfigProto( device_count = {'GPU': 1 , 'CPU': 4} ) 
sess = tf.Session(config=config) 
keras.backend.set_session(sess)

import numpy as np
from metrics_utils import *
from preprocess_utils import *
from models import *
from embeddings_utils import *
from keras.callbacks import ModelCheckpoint

VOCAB_SIZE = 272785
EMB_SIZE = 300
EMB_PATH = "./glove_300/model.txt"
NO_CLASSES = 2

if __name__ == '__main__':
    # Load the data
    data_dict = load_dataset()

    # Concatenate train, validation and test
    all_data = data_dict[ALL][X]

    # Create tokenizer
    tokenizer = tokenize(VOCAB_SIZE, all_data)

    # Create sequences
    X_train = samples_to_seq(tokenizer, data_dict[TRAIN][X])
    X_test = samples_to_seq(tokenizer, data_dict[TEST][X])
    X_val = samples_to_seq(tokenizer, data_dict[VAL][X])

    # Convert labels & one-hot encode them
    y_train = labels_to_categ(data_dict[TRAIN][Y], NO_CLASSES)
    y_test = labels_to_categ(data_dict[TEST][Y], NO_CLASSES)
    y_val = labels_to_categ(data_dict[VAL][Y], NO_CLASSES)

    # Use pre-trained embeddings
    emb_index = extract_embeddings(EMB_PATH)
    emb_matrix = create_weight_matrix(tokenizer, emb_index, EMB_SIZE, VOCAB_SIZE)

    # Create the model
    model = create_lstm_model(emb_matrix, EMB_SIZE, VOCAB_SIZE, NO_CLASSES)

    # Fit train data
    filepath="checkpoints/weights-improvement-{epoch:02d}-acc-{val_accuracy:.2f}-loss-{val_loss:.2f}.hdf5"
    checkpoint = ModelCheckpoint(filepath, monitor='val_accuracy', verbose=1, save_best_only=True, mode='max')

    metrics = Metrics()
    callbacks_list = [checkpoint, metrics]

    model.fit(X_train, 
              np.array(y_train), 
              validation_data=(X_val, y_val), 
              batch_size = 128, 
              epochs = 1,
              callbacks = callbacks_list,
              verbose = 1)

    results = test_model(model, X_test, y_test, batch_size=128)
    model.save("model.h5")
    print(results) 
